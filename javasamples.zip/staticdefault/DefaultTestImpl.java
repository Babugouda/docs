package staticdefault;

interface DefaultTest {

	default void testDefault() {
		System.out.println("Testing DefaultTest default");
	}

	static void testStatic() {
		System.out.println("Testing DefaultTest Static");
	}

}

interface DefaultTest2 {

	default void testDefault() {
		System.out.println("Testing DefaultTest2 default");
	}

	static void testStatic() {
		System.out.println("Testing DefaultTest2 Static");
	}
}

public class DefaultTestImpl implements DefaultTest, DefaultTest2 {

	public static void main(String[] args) {
		DefaultTestImpl testImpl = new DefaultTestImpl();
		testImpl.testDefault();
	}

	@Override
	public void testDefault() {
		DefaultTest.super.testDefault();
		DefaultTest2.super.testDefault();
		DefaultTest.testStatic();
		DefaultTest2.testStatic();
	}

}
package lambda;

public class LambdaTest {

	public static void main(String[] args) {
		Runnable r = () -> System.out.println("test");
		Thread t = new Thread(r);
		t.start();

		Thread t2 = new Thread(() -> System.out.print("Test2"));
		t2.start();
	}

}

package methodref;

//Method references Applicable only to functional interface

interface Sayable {
	void say();
}

interface Sayable2 {
	void say();
}

interface Sayable3 {
	String say();
}

public class MethodReference2 {

	public static void saySomething() {
		System.out.println("hello, This is static method");
	}

	public void saySomeOtherThing() {
		System.out.println("This is instace method");
	}
	
	public String returnData(){
		return "hello from returnData";
	}

	public static void main(String[] args) {
		MethodReference2 ref2 = new MethodReference2();
		// Instance reference
		Sayable sayable = ref2::saySomeOtherThing;
		sayable.say();

		// Static reference
		Sayable2 sayable2 = MethodReference2::saySomething;
		sayable2.say();
		
		//MethodReference2 ref2 = new MethodReference2();
		// Instance reference
		Sayable3 sayable3 = ref2::returnData;
		ref2.returnData();
		System.out.println(sayable3.say());
	}
}

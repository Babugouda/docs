package hashing;

import java.util.HashMap;
import java.util.Map;

public class TestHashMap {

	public static void main(String[] args) {
		
		Map<Employee,Employee> a=new HashMap<>();
		Employee e1=new Employee();
		e1.setId(10);
		a.put(e1, e1);
		
		Employee e2=new Employee();
		e2.setId(10);
		a.put(e2, e2);
		
		System.out.println(a.size()); //Size is 1
		System.out.println(e1.hashCode()); //hash value of 1 and 2 are different
		System.out.println(e2.hashCode());
		

	}

}

package streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {

		Integer[] intArray = { 10, 20, 30, 40 };
		List<Integer> intList = new ArrayList<>(Arrays.asList(intArray));
		// Stream->sequence of objects from any source
		System.out.println("-----------------------------------------------------------");
		System.out.println("Filter data" + intList);
		System.out.println("Filter using streams");
		List<Integer> filterList = intList.stream().filter(p -> p > 10).sorted().collect(Collectors.toList());
		System.out.println(filterList);

		System.out.println("-----------------------------------------------------------");
		System.out.println("List of data: " + intList);
		System.out.println("IntSummaryStatistics stream it gives aggregation functions ");
		IntSummaryStatistics stat = intList.stream().mapToInt(i -> i).summaryStatistics();
		System.out.println("Avg: " + stat.getAverage());
		System.out.println("Count: " + stat.getCount());
		System.out.println("Max: " + stat.getMax());
		System.out.println("Min: " + stat.getMin());
		System.out.println(stat);

		List<String> strList = new ArrayList<>(Arrays.asList("aa", "bb", "ccc", "ddddd", "ffffff"));
		System.out.println("-----------------------------------------------------------");
		System.out.println("List of data: " + strList);
		System.out.println("Join using stream");
		// Join
		String stringJoin = strList.stream().collect(Collectors.joining("---"));
		System.out.println("Joined data: " + stringJoin);

		System.out.println("-----------------------------------------------------------");
		// Random numbers with stream
		Random random = new Random();
		System.out.println("Randam numbers");
		random.ints().limit(5).sorted().forEach(p -> System.out.print(" " + p));
	}
}

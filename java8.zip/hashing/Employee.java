package hashing;

public class Employee {

	private int id;

	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// When we won't implement hashcode it will use objects hashcode method to
	// generate hash value, it will be always different for different objects,
	// according to equals and hashcode contract 2 objects are not equal if hash
	// values are different
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	// When we implement hashcode without equals method then 2 objects will
	// always be treated as different even though objects are same
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		return true;
	}

}

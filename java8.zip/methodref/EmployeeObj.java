package methodref;

interface TestmethodRef {

	public Integer getSal();
}

public class EmployeeObj {

	private Integer sal;

	public EmployeeObj(Integer sal) {
		this.setSal(sal);
	}

	public Integer getSal() {
		return sal;
	}

	public void setSal(Integer sal) {
		this.sal = sal;
	}

	public static void main(String[] args) {
		EmployeeObj obj = new EmployeeObj(20000);
		// Applicable only to functional interface
		TestmethodRef ref = obj::getSal;
		System.out.println(ref.getSal());
	}

}

package methodref;

interface Adder {
	int add();
}

interface Substractor {
	int sub();
}

interface Multiplier {
	int mul();
}

interface Divisor {
	int div();
}

public class Calculator {
	int a;
	int b;

	public Calculator(int a, int b) {
		this.a = a;
		this.b = b;
	}

	int adder() {
		return a + b;
	}

	int subtractor() {
		return b - a;
	}

	int multiplier() {
		return a * b;
	}

	int divisor() {
		return b / a;
	}

	// Analyze the usage
	public static void main(String[] args) {
		Calculator c = new Calculator(10, 20);

		System.out.println(c.subtractor());

		Adder adder = c::adder;
		System.out.println(adder.add());

		Substractor sub = c::subtractor;
		System.out.println(sub.sub());

		Multiplier mul = c::multiplier;
		System.out.println(mul.mul());

		Divisor div = c::divisor;
		System.out.println(div.div());
	}
}

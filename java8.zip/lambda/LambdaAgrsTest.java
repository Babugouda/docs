package lambda;

@FunctionalInterface
interface LambdaOneArgs {
	public void dispArgs(int a);

	static void staticMethod() {
		System.out.println("Static method in LambdaOneArgs");
	}
}

@FunctionalInterface
interface LambdaTwoArgs {
	public void addArgs(int a, int b);
}

@FunctionalInterface
interface LambdaTwoArgsOneReturn {
	public int addArgs(int a, int b);
}

public class LambdaAgrsTest {
	public static void main(String[] args) {
		LambdaOneArgs l = (i) -> System.out.println("Passsed argument: " + i);
		l.dispArgs(10);
		LambdaOneArgs.staticMethod();

		LambdaTwoArgs adder = (a, b) -> System.out.println("Sum of two numbers: " + (a + b));
		adder.addArgs(10, 20);
		// data type must be given all or none in method param list
		LambdaTwoArgsOneReturn adder2 = (int a, int b) -> (a + b);
		System.out.println("Sum of two numbers: " + adder2.addArgs(10, 40));
	}
}
